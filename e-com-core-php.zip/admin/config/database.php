<?php
$link=mysqli_connect("localhost","root","","ducat") or die("Not connect");
?>